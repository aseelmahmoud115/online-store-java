/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my_store;

public class Item {
    private int itemNumber;
    private String itemName;
    private int itemQuantity;
    double itemPrice;
    static int count = 001 ;

    public Item(int itemNumber ,  String itemName, int itemQuantity, double itemPrice) {
        this.itemNumber = count ;
        count++ ; 
        this.itemName = itemName;
        this.itemQuantity = itemQuantity;
        this.itemPrice = itemPrice;  }

    public void setItemNumber(int itemNumber) {
        this.itemNumber =  itemNumber ; }

    public void setItemName(String itemName) {
        this.itemName = itemName; }
    
    public void setItemQuantity(int itemQuantity) {
        this.itemQuantity = itemQuantity; }

    public void setItemPrice(double itemPrice) {
        this.itemPrice = itemPrice; }

    public int getItemNumber() {
        return  itemNumber ; }

    public String getItemName() {
        return itemName; }

    public int getItemQuantity() {
        return itemQuantity; }

    public double getItemPrice() {
        return itemPrice; }
   
    public String toString() {
        return itemNumber + "[ " + itemName + "[" + itemQuantity + "]" + " ]" ; }
}

