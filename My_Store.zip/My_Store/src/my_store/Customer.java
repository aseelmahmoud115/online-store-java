/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my_store;

import java.util.ArrayList;

public class Customer {
    int customer_no;
    String customer_name;
    private ArrayList<Item> shoppingCart;

    public Customer(int customer_no , String customer_name) {
        this.customer_no = customer_no ;
        this.customer_name = customer_name;
        shoppingCart = new ArrayList<Item>(); }

    public int getCustomer_no() {
        return customer_no; }

    public String getCustomer_name() {
        return customer_name; }

    public ArrayList<Item> getShoppingCart() {
        return shoppingCart; }

    public void addItemToCart(Item item, int quantity) {
        if (item.getItemQuantity() >= quantity) {
        item.setItemQuantity(item.getItemQuantity() - quantity);
        Item newItem = new Item(item.getItemNumber() , item.getItemName(), quantity, item.getItemPrice());
        shoppingCart.add(newItem);
        System.out.println("The item is "+newItem+" adding to shopping cart is success"); }
        else  {
        System.out.println("Sorry the required quantity is not available, the available quantity is[" + item.getItemQuantity() + "],try again!"); }
    } 

    public void removeItemFromCart(int itemIndex) {
        Item item = shoppingCart.get(itemIndex);
        shoppingCart.remove(itemIndex);
        System.out.println("The item [" + item + "] is removed from shopping cart.");
    }

    public void emptyCart() {
        shoppingCart.clear();
        System.out.println("The shopping cart is emptied.");
    }

    public String toString() {
        return customer_no + " " + customer_name; }
}
