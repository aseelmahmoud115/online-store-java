
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my_store;

import java.util.Scanner;

public class My_Store {

public static void main(String[] args) {
 Scanner scanner = new Scanner(System.in);
  Shopping_cart cart = new Shopping_cart();
    while (true) {
        System.out.println();
        System.out.println("Store System Menu :");
        System.out.println("1. Add a new Item to Store");
        System.out.println("2. Add a new Customer to Store");
        System.out.println("3. Add an item to Customer shopping cart");
        System.out.println("4. Remove an item from Customer shopping cart");
        System.out.println("5. View the items in Customer shopping cart");
        System.out.println("6. Modify customer data");
        System.out.println("7. Empty Customer shopping cart");
        System.out.println("8. End shopping and go to checkout");
        System.out.println("9. Exit the program");

        System.out.print("Enter your option: ");
        int option = scanner.nextInt(); 
        System.out.println();
    switch (option) {
        case 1:
    System.out.println("Add Item Operation:");
        while (true) {
        System.out.println("Please enter the item number: "+Item.count);
        int itemNumber = Item.count  ;
        System.out.print("Please enter the item Name: ");
        String itemName = scanner.next();
        System.out.print("Please enter the quantity: ");
        int itemQuantity = scanner.nextInt();
        System.out.print("Please enter the price: ");
        double itemPrice = scanner.nextDouble();
        System.out.print("Enter the type of item (B)Book, (s)shoes, (G)Game ? : ");
        String itemType = scanner.next();
        if ("B".equalsIgnoreCase(itemType)){
        System.out.print("Enter the Book title: ");
        String bookTitle = scanner.next();
        System.out.print("Enter the Book author name: ");
        String bookAuthor = scanner.next(); 
        Item item = new Item( itemNumber ,itemName, itemQuantity, itemPrice);
        cart.addItem(item); }
        else {
        Item item = new Item( itemNumber , itemName, itemQuantity, itemPrice);
        cart.addItem(item); }
        System.out.print("Do you want add another item (y/n)? ");
        String addAnother = scanner.next();
        if ("N".equalsIgnoreCase(addAnother)) { break; } }
            break;
            
        case 2: 
    System.out.println("Add new Customer Operation:");
        while (true) {
        System.out.print("Please enter the customer number: ");
        int customerNumber = scanner.nextInt();
        System.out.print("Please enter the customer Name: ");
        String customerName = scanner.next();
        Customer customer = new Customer(customerNumber, customerName);
         cart.addCustomer(customer);
        System.out.print("Do you want add another customer (y/n)? ");
        String addAnother = scanner.next();
        if ("N".equalsIgnoreCase(addAnother)) { break; } }
            break;
            
        case 3:
    System.out.println("Add Item to Customer Shopping Cart Operation:");
        while (true) {
        System.out.print("Please Enter customer number: ");
        int ID = scanner.nextInt();
        Customer customer = cart.getCustomer(ID);
        if (customer == null) {
        System.out.print("The customer is not exists, Do you want try again(y/n)? ");
        String tryAgain = scanner.next();
        if ("N".equalsIgnoreCase(tryAgain)){ break; }}
        else {
        System.out.println("The customer no :"+ID+","+"The customer name :"+customer.getCustomer_name());
        cart.displayItems();
        System.out.print("Enter your choice item: ");
        int itemChoice = scanner.nextInt();
        if (itemChoice == 0) { break ; }
        Item item = cart.getItem(itemChoice);
        System.out.print("Enter the quantity you need: ");
        int quantity = scanner.nextInt();
        customer.addItemToCart(item, quantity);
        System.out.print("Do you want add another item to shopping cart (y/n)? ");
        String addAnother = scanner.next();
        if ("N".equalsIgnoreCase(addAnother)) { break; } }}
            break;
            
        case 4:
    System.out.println(" Remove Item from Customer Shopping Cart Operation:");
        System.out.print("Enter customer number: ");
        int ID = scanner.nextInt();
        Customer customer = cart.getCustomer(ID);
        if (customer == null) {
        System.out.println("The customer is not exists."); }
        else {
        System.out.println("The customer no :" + ID + ", The customer name : " + customer.getCustomer_name() + ".");
        System.out.println("The current items in the shopping cart.");
        int i = 1;
        for (Item item : customer.getShoppingCart()) {
        System.out.println(">>> " +i+ ". " + item);
        i++; }
        System.out.println("What you want to modify?");
        System.out.println(">>> R. Remove item form the shopping cart." +"\n"+ ">>> M. Return to main menu.");
        System.out.print("Enter your choice [R Remove, M main menu]: ");
        String modifyChoice = scanner.next();
        if ("R".equalsIgnoreCase(modifyChoice)){
        System.out.print("Enter Your item option number : ");
        int itemIndex = scanner.nextInt()-1; 
        customer.removeItemFromCart(itemIndex); }}
            break;
            
        case 5:
    System.out.println("View the items in Customer shopping cart Operation:");
        System.out.print("Enter customer number: ");
        ID = scanner.nextInt();
        customer = cart.getCustomer(ID);
        if (customer == null) {
        System.out.println("The customer is not exists."); }
        else {
        cart.displayCart(customer); 
        System.out.print("Press (m/M) key to return to the main menu : ");
        char returnToMenu = scanner.next().charAt(0); }
            break ; 
            
        case 6:
    System.out.println("Modify Customer Data:");
        while (true) {
        System.out.print("Enter customer number: ");
        ID = scanner.nextInt();
        customer = cart.getCustomer(ID);
        if (customer == null) {
        System.out.println("The customer no :" + ID + " not found.");
        System.out.print("Do you want modify another item (y/n)? ");
        String modifyAnother = scanner.next();
        if ("N".equalsIgnoreCase(modifyAnother)) { break; }} 
        else {
        System.out.println("The customer no :" + ID + ", The customer name : " + customer.getCustomer_name() + ".");    
        System.out.print("Please enter the customer number : ");
        int newNumber = scanner.nextInt();
        System.out.print("Please enter the customer Name : ");
        String newName = scanner.next();
        cart.modifyCustomer(customer, newNumber, newName);
        System.out.print("Do you want modify another item (y/n)? ");
        String modifyAnother = scanner.next();
        if ("N".equalsIgnoreCase(modifyAnother)) { 
        System.out.println("back to main menu");
        break; }}}
            break ;
           
        case 7:
    System.out.println("Empty Customer shopping cart Operation:");
        System.out.print("Enter customer number: ");
        ID = scanner.nextInt();
        customer = cart.getCustomer(ID);
        if (customer == null) {
        System.out.println("The customer is not exists."); }
        else {
        customer.emptyCart(); }
            break ;
             
        case 8:
    System.out.println("End shopping and go to checkout Operation:");
        System.out.print("Enter customer number: ");
        ID = scanner.nextInt();
        customer = cart.getCustomer(ID);
        if (customer == null) {
        System.out.println("The customer is not exists."); } 
        else {
        cart.displayCart(customer);
        cart.removeCustomer(customer); }
            break ;
            
        case 9:
    System.out.println("Exiting the program…");
        System.exit(0);
            break ;
            
        default:
        System.out.println("Invalid choice, please try again.");
             break;
}}}}
    
    