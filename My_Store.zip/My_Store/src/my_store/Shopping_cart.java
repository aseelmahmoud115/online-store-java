/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my_store;

import java.util.ArrayList;

public class Shopping_cart {
    private ArrayList<Item> items;
    private ArrayList<Customer> customers;

    public Shopping_cart() {
        this.items = new ArrayList<Item>();
        this.customers = new ArrayList<Customer>(); }

    public void addItem(Item item) {
        items.add(item);
        System.out.println("Item added Successfully"); }

    public void addCustomer(Customer customer) {
        customers.add(customer);
        System.out.println("Customer added with empty shopping cart Successfully"); }

    public Item getItem(int itemNumber) {
        for (Item item : items) {
        if (item.getItemNumber() == itemNumber) {
            System.out.println("The item is ["+ item.getItemName()+"["+item.getItemQuantity()+"]]");
            return item ; }
        } return null; }

    public Customer getCustomer(int customerNumber) {
        for (Customer customer : customers) {
        if (customer.getCustomer_no() == customerNumber) {
            return customer; }
        } return null; }
    
    public void modifyCustomer(Customer customer, int newNumber, String newName) {
        customer.customer_no = newNumber;
        customer.customer_name = newName;
        System.out.println("Customer modified Successfully"); }
    
    public void removeCustomer(Customer customer) {
        customers.remove(customer);
        System.out.println("The customer [" + customer + "] is removed from the store.");  }

    public void displayItems() {
        System.out.println("Items in the store"); 
        for (Item item : items) {
        System.out.println(">>> " + item); }
        System.out.println(">>> 0. Return to the main menu"); }

    public void displayCart(Customer customer) {
        System.out.println("Item no\t Item name\t Quantity\t Unit price\t Total price");
        double totalPrice = 0 ;
        for (Item item : customer.getShoppingCart()) {
        double itemTotalPrice = item.getItemPrice() * item.getItemQuantity();
        System.out.println(item.getItemNumber()+"\t\t"+item.getItemName()+"\t\t"+item.getItemQuantity()+"\t\t"+item.getItemPrice()+"\t\t"+itemTotalPrice);
        totalPrice += itemTotalPrice; }
        System.out.println("\t\t\t\t\t\t\t\t\tTotal price " + totalPrice); }  
}
